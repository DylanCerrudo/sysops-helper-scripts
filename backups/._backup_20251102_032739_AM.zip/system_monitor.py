"""
System Monitoring & Alerting
Real-Time system resource monitoring with threshold-based alerts.
Tracks CPU, memory, and disk usage to prevent system issues.
"""

import psutil
import time
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


class SystemMonitor:
    """
    Monitors System resources and triggers alerts when thresholds are exceeded.
    """
    def __init__(self, cpu_threshold=80, memory_threshold=85, disk_threshold=90):
        """
        Initialize the system monitor with alert thresholds.
        """
        self.cpu_threshold = cpu_threshold
        self.memory_threshold = memory_threshold
        self.disk_threshold = disk_threshold
        self.alert_log = []
    
    
    def get_system_stats(self):
        """
        Collects current system resource usage statistics.
        """
        
        cpu_percent = psutil.cpu_percent(interval=1)
        
        
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        
        
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        
        
        cpu_count = psutil.cpu_count()
        memory_total_gb = memory.total / (1024**3)
        memory_used_gb = memory.used / (1024**3)
        disk_total_gb = disk.total / (1024**3)
        disk_used_gb = disk_used_gb / (1024**3)
        
        return{
            'timestamp': datetime.now().strftime('%Y-%m-%d % I:%M:%S %p'),
            'cpu_percent': cpu_percent,
            'cpu_count': cpu_count,
            'memory_percent': memory_percent,
            'memory_total_gb': round(memory_total_gb, 2),
            'memory_used_gb': round(memory_used_gb, 2),
            'disk_percent': disk_percent,
            'disk_total_gb': round(disk_total_gb, 2),
            'disk_total_used': round(disk_used_gb, 2)
        }
        
    def check_thresholds(self, stats):
        """
        Checks if any resource usage exceeds defined thresholds.
        """
        
        
        alerts = []
        
        #Check CPU threshold
        if stats['cpu_percent'] > self.cpu_threshold:
            alerts.append(
                f"HIGH CPU USAGE: {stats['cpu_percent']:.1f}% "
                f"(Threshold: {self.cpu_threshold}%)"
            )
            
        if stats['memory_percent'] > self.memory_threshold:
            alerts.append(
                f"HIGH MEMORY USAGE: {stats['memory_percent']:.1f}% "
                f"(Threshold: {self.memory_threshold}%)"
            )
        
        if stats['disk_percent'] > self.disk_threshold:
            alerts.append(
                f"HIGH DISK USAGE: "
            )
        